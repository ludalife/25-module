valid_email = "pet_test_vv@mail.com"
valid_password = "12345"

invalid_email = 'fantast23@mail.com'
invalid_password = 'abcd0'
 
